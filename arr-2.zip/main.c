/******************************************************************************

wap to cal sum total and average marks of five students in exam

*******************************************************************************/
#include <stdio.h>

int main()
{
 int i,arr[5],sum=0,avg=0;
 for(i=0;i<=4;i++)
 {
     printf("\nenter an array");
     scanf("%d",&arr[i]);
     sum=sum+arr[i];
}
avg=sum/5;
printf("\naverage = %d\n",avg);
printf("sum = %d",sum);
return 0;
}



