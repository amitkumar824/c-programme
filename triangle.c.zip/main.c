/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
main()
{
    int x,y,z,tot;
    printf("enter three angles of triangle");
    scanf("%d%d%d",&x,&y,&z);
    tot=x+y+z;
    if(tot==180)
    {
        printf("triangle is valid");
    }
    else
    {
        printf("invalid input");
    }
}

