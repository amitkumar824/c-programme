/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include<stdio.h>
 void main()
{
    int i,n,sum;
    float avg;
    printf("enter no. of students = ");
    scanf("%d",&n);
    int a[n];
    for(i=0;i<n;i++)
    {
        printf("enter marks of student %d =",i+1);
        scanf("%d",&a[i]);
    }
    for(i=0;i<n;i++)
    {
       sum+=a[i];
      }
    avg=sum/n;
    printf("sum of marks = %d \n avg marks = %f ",sum,avg);
    
    
}