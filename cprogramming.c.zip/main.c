/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include<stdio.h>
void main()
{
    int cyr,jyr,ys,bonus;
    printf("enter the year of joining and the current year\n");
    scanf("%d%d",&jyr,&cyr);
    ys=cyr-jyr;
    if(ys>3)
    {
    bonus=2500;
    printf("%d",bonus);
    }
}