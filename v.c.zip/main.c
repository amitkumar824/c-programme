/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>
void main()
{
   int a=4,b=5,c=6,d=7,e=8;
   float avg=(a+b+c+d+e)/5;
   printf("the first no is %d \n",a);
   printf("the second no is %d \n",b);
   printf("the third no is %d \n",c); 
   printf("the fourth no is %d \n",d); 
   printf("the fifth no is %d \n",e); 
   printf("the average is %f \n",avg); 
}