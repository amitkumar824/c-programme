/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include<stdio.h>
int
main ()
{
  int n, i,sum=0;
  int fact, rem;
  printf ("Enter a number : ");
  scanf ("%d", &n);
  int temp = n;
  while (n)
    {
      i = 1, fact = 1;
      rem = n % 10;
      while (i <= rem)
	{
	  fact = fact * i;
	  i++;
	}
      sum=sum + fact;
      n=n / 10;
    }
  if (sum == temp)
  {
    printf ("%d is a strong number", temp);
  }
  else 
  {
    printf ("%d is not a strong number", temp);
  }
  return 0;
}
