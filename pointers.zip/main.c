/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
int main()
{
    int i=3,*j,**k;
    j=&i;
    k=&j;
    printf("Address of i=%u",&i);
    printf("Address of i=%u",j);
    printf("Address of i=%u",*k);
    printf("Address of j=%u",&j);
    printf("Address of j=%u",k);
    printf("Address of k=%u",&k);
    printf("Address of i=%u",j);
    printf("Address of k=%u",k);
    printf("Address of i=%d",i);
    printf("Address of i=%d",*(&i));
    printf("Address of i=%d",*j);
    printf("Address of i=%d",**k);
}