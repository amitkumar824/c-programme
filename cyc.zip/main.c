/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
void main()
{
    int x,y,r,dis,d;
    printf("enter the values");
    scanf("%d%d%d",&x,&y,&r);
    dis=(x*x)+(y*y);
    d=(r*r);
    if(dis<d)
    {
        printf("inside the circle");
    }
    else if(dis>d)
    {
        printf("outside the circle");
    }
    else if(dis==d)
    {
        printf("on the circle");
    }
}

