/************************************************
if the ages of three children r entered throgh
the keyboard wap to cal the oldest of the three
*********************************/
#include <stdio.h>
main()
{
 int a,b,c;
 printf("enter the ages of the childrens(max up to 3)");
 scanf("%d%d%d",&a,&b,&c);
 if(a>c&&a>b)
 {
     printf("first is the oldest one");
 }
 else if(b>a&&b>c)
 {
     printf("second children is the oldest");
 }
 else if(c>a&&c>b)
 {
     printf("third children is the oldest");
}
}