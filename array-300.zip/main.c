/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#define N 10
int main()
{
int a[N],i,p=0,n=0,z=0;
printf("enter %d elements",N);
for(i=0;i<N;i++)
{
    scanf("%d",& a[i]);
}
for(i=0;i<N;i++)
{
    if(a[i]>0)
    p++;
    else if (a[i]<0)
    n++;
    else
    z++;
}
printf("positive count%d",p);
printf("\n negative count%d",n);
printf("\n zero count%d",z);
}




    

