/******************************************************************************
wap to find largest element in an array
*******************************************************************************/
#include <stdio.h>

int main()
{
 int i,largest,udef;
 printf("enter the size of array");
 scanf("%d",&udef);
 int arr[udef];
 printf("enter %d elements of an array",udef);
 for(i=0;i<=udef-1;i++)
 {
     scanf("%d",&arr[i]);
 }
 largest=arr[0];
 for(i=0;i<=udef-1;i++)
 {
     if(largest<arr[i])
     {
         largest=arr[i];
     }
 }
 printf("largest element of an array is %d",largest);
 return 0;
}

