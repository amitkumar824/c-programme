/*************************************************************************
Wap to input ARRAY OF N NO OF ELEMENTS and store an even no in first array
and odd no in second array and print threm seperately?
*************************************************************************/
#include <stdio.h>

int main()
{
    int n,i,a[],E[],O[];
    printf("enter the ")
    for(i=0;i<n;i++)
    {
        scanf("%d",&a[i]);
    }
    if (a[i]%2==0)
    {
        for(i=0;i<n;i++)
        {
    }
    
}

