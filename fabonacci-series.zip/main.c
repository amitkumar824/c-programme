/******************************************************************************
 * wap to enter a no and print fabonacci series upto that no
*******************************************************************************/
#include <stdio.h>

int main()
{
  int n,t1=0,t2=1,nxt_term=0;
  printf("enter a no");
  scanf("%d",&n);
  printf("fibonacci series:%d,%d,",t1,t2);
  nxt_term=t1+t2;
  while(nxt_term<=n)
  {
      printf("%d,",nxt_term);
      t1=t2;
      t2=nxt_term;
      nxt_term=t1+t2;
  }
  return 0;
}

