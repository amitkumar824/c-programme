/******************************************************************************

wap  to enter an array of five elements and print array of five elements

*******************************************************************************/
#include <stdio.h>

int main()
{
 int i,arr[5];
 for(i=0;i<=4;i++)
 {
     printf("\n enter array");
     scanf("%d",&arr[i]);
 }
 for(i=0;i<=4;i++)
 {
     printf("\n%d",arr[i]);
 }
 return 0;
}

