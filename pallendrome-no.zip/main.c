/******************************************************************************
 * wap to reverse a no and check wheaather it is a pallendrome no


*******************************************************************************/
#include <stdio.h>

int main()
{
    int temp,n,r,sum=0;
    printf("enter a no");
    scanf("%d",&n);
    temp=n;
    while(n>0)
    {
        r=n%10;
        sum=sum*10+r;
        n=n/10;
    }
    if(sum==temp)
    {
        printf("palendrome no");
    }
    else
    {
        printf("not a Palendrome no");
    }
}

