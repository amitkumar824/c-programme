/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

main()
{
 int x,y;
 printf("enter the coordinates");
 scanf("%d%d",&x,&y);
 if(x==0&&y==0)
 {
     printf("origin");
 }
 else if(x!=0&&y==0)
 {
     printf("on y axis");
 }
 else if(x==0&&y!=0)
 {
     printf("on x axis");
 }
 else
 {
     printf("somewhere on the xy plane");
}
}
